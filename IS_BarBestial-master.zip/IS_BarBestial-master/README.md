# IS_BarBestial
Implementación del juego de mesa Bar Bestial para la asignatura "Ingeniería del Software" del Grado de Ingeniería Informática de Gestión y Sistemas de Información de la UPV/EHU.
