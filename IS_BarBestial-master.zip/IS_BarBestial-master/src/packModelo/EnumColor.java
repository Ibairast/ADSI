package packModelo;

public enum EnumColor {
    AZUL, VERDE
}
