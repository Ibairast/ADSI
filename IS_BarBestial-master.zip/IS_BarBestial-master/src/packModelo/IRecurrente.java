package packModelo;

public interface IRecurrente {}
