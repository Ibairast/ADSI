package packPrincipal;

import packControlador.Controlador;

public class BarBestial {
    public static void main(String[] args) {
        Controlador controlador = new Controlador();
        controlador.iniciarAplicacion();
    }
}
